/* eslint-disable  */
import React, { createContext, useState, useEffect, useContext } from "react";
import axios from "axios";
import { useNavigate, useLocation } from "react-router-dom";
import LoadingScreen from "../components/common/LoadingScreen";
import { getErrorMessage } from "../utils/errorHandler";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  //AXIOS INTERCEPTOR
  useEffect(() => {
    // 1. Request Interceptor: Attach Token
    const reqInterceptor = axios.interceptors.request.use(
      (config) => {
        const token = localStorage.getItem("access_token");
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // 2. Response Interceptor: Handle 401 Token Expiry
    const resInterceptor = axios.interceptors.response.use(
      (response) => response,
      async (error) => {
        const originalRequest = error.config;

        // If error is 401 (Unauthorized)
        if (
          error.response?.status === 401 &&
          !originalRequest._retry &&
          localStorage.getItem("refresh_token")
        ) {
          originalRequest._retry = true;

          try {
            // Attempt to refresh token
            const refreshToken = localStorage.getItem("refresh_token");
            const res = await axios.post(
              `${import.meta.env.VITE_API_URL}/api/auth/token/refresh/`,
              { refresh: refreshToken }
            );

            // Save new tokens
            const newAccess = res.data.access;
            localStorage.setItem("access_token", newAccess);

            // Retry original request with new token
            originalRequest.headers.Authorization = `Bearer ${newAccess}`;
            return axios(originalRequest);
          } catch (refreshError) {
            console.error("Session expired completely.", refreshError);
            logout(); // If refresh fails, force logout
          }
        }
        return Promise.reject(error);
      }
    );

    // Cleanup interceptors on unmount
    return () => {
      axios.interceptors.request.eject(reqInterceptor);
      axios.interceptors.response.eject(resInterceptor);
    };
  }, [navigate]);

  const handleRedirect = (userData) => {
    if (!userData) return;
    if (!userData.is_setup_complete) {
      if (location.pathname !== "/setup") navigate("/setup");
    } else if (
      location.pathname === "/login" ||
      location.pathname === "/setup"
    ) {
      navigate("/");
    }
  };

  useEffect(() => {
    const checkLoggedIn = async () => {
      //authentication check
      const performAuthCheck = async () => {
        const token = localStorage.getItem("access_token");
        if (token) {
          try {
            const res = await axios.get(
              `${import.meta.env.VITE_API_URL}/api/user/me/`
            );
            setUser(res.data);
            handleRedirect(res.data);
          } catch (error) {
            // Only logout if token is missing/invalid, otherwise keep silent
            if (!localStorage.getItem("access_token")) logout();
          }
        }
      };

      //Delay Logic
      if (loading) {
        //INITIAL LOAD (Spinner Active)
        await Promise.all([
          performAuthCheck(),
          new Promise((resolve) => setTimeout(resolve, 1000)), //1 Sec Delay
        ]);

        // Only hide spinner after 1 seconds have passed
        setLoading(false);
      } else {
        await performAuthCheck();
      }
    };

    checkLoggedIn();
  }, [location.pathname]);

  const handleAuthResponse = (res) => {
    const { access, refresh, user: userData } = res.data;
    localStorage.setItem("access_token", access);
    localStorage.setItem("refresh_token", refresh);
    setUser(userData);
    handleRedirect(userData);
  };

  const googleLogin = async (googleData) => {
    try {
      const res = await axios.post(
        `${import.meta.env.VITE_API_URL}/api/auth/google/`,
        { access_token: googleData.access_token }
      );
      handleAuthResponse(res);
      return { success: true };
    } catch (error) {
      return { success: false, error: "Google login failed." };
    }
  };

  const login = async (email, password) => {
    try {
      const res = await axios.post(
        `${import.meta.env.VITE_API_URL}/api/auth/login/`,
        { email, password }
      );
      handleAuthResponse(res);
      return { success: true };
    } catch (error) {
      return { success: false, error: getErrorMessage(error) };
    }
  };

  const register = async (name, email, password) => {
    try {
      // 1. Split Name
      const nameParts = name.trim().split(/\s+/);

      // Safety fallback if validation is bypassed
      const firstName = nameParts[0];
      const lastName = nameParts.length > 1 ? nameParts.slice(1).join(" ") : "";

      // 2. Generate Username
      const baseName = name.toLowerCase().replace(/\s+/g, "");
      const randomSuffix = Math.floor(1000 + Math.random() * 9000);
      const generatedUsername = `${baseName}${randomSuffix}`;

      const res = await axios.post(
        `${import.meta.env.VITE_API_URL}/api/auth/registration/`,
        {
          username: generatedUsername,
          email: email,
          password1: password,
          password2: password,
          first_name: firstName,
          last_name: lastName,
        }
      );

      handleAuthResponse(res);
      return { success: true };
    } catch (error) {
      return { success: false, error: getErrorMessage(error) };
    }
  };

  const resetPassword = async (email) => {
    try {
      await axios.post(
        `${import.meta.env.VITE_API_URL}/api/auth/password/reset/`,
        { email }
      );
      return { success: true };
    } catch (error) {
      return { success: false, error: getErrorMessage(error) };
    }
  };

  const resetPasswordConfirm = async (uid, token, newPassword) => {
    try {
      await axios.post(
        `${import.meta.env.VITE_API_URL}/api/auth/password/reset/confirm/`,
        {
          uid,
          token,
          new_password1: newPassword,
          new_password2: newPassword,
        }
      );
      return { success: true };
    } catch (error) {
      return { success: false, error: getErrorMessage(error) };
    }
  };

  const logout = () => {
    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
    setUser(null);
    navigate("/login");
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        googleLogin,
        login,
        register,
        resetPassword,
        resetPasswordConfirm,
        logout,
      }}
    >
      {/* If loading, show the loading screen. Otherwise show the App. */}
      {loading ? <LoadingScreen /> : children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
